
### HOWTO
pip3 install bitmex


### LICENSE
MIT

